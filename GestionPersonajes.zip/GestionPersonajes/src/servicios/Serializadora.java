
package servicios;

import modelos.Personaje;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;


public class Serializadora {
    
    public static void serializarPersonajes(List<? extends Personaje> lista, String path) {

        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            salida.writeObject(lista);
            
        } catch (IOException ex) {
            ex.printStackTrace();
            System.out.println(ex.getMessage());

        }
    }

    public static List<Personaje> deserializarPersonajes(String path) {
        List<Personaje> toReturn = null;
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
            toReturn = (List<Personaje>) entrada.readObject();
        } catch (IOException | ClassNotFoundException ex) {

            System.out.println(ex.getMessage());

        }
        return toReturn;
    }
}
