
package gestionpersonajes;

import modelos.ClasePersonaje;
import modelos.Personaje;
import modelos.Inventario;
import static config.AppConstants.PATH_CSV;
import static config.AppConstants.PATH_SERIAL;
import modelos.CSVSerializable;

public class GestionPersonajes {

    public static void main(String[] args) {
        try {
            // Crear inventario
            Inventario<Personaje> inventarioPersonajes = new Inventario<>();
            inventarioPersonajes.agregar(new Personaje(1, "Aragorn", ClasePersonaje.GUERRERO, 20));
            inventarioPersonajes.agregar(new Personaje(2, "Gandalf", ClasePersonaje.MAGO, 50));
            inventarioPersonajes.agregar(new Personaje(3, "Legolas", ClasePersonaje.ARQUERO, 25));
            inventarioPersonajes.agregar(new Personaje(4, "Frodo", ClasePersonaje.GUERRERO, 10));
            inventarioPersonajes.agregar(new Personaje(5, "Saruman", ClasePersonaje.MAGO, 40));
            inventarioPersonajes.agregar(new Personaje(6, "Robin Hood", ClasePersonaje.ARQUERO, 30));

            // Mostrar todos los personajes en el inventario
            System.out.println("Inventario de personajes:");
            inventarioPersonajes.paraCadaElemento((personaje) -> System.out.println(personaje));
            
            // Ordenar de manera natural por nombre
            System.out.println("\nPersonajes ordenados por nombre:");
            inventarioPersonajes.mostrarContenido(); 
            inventarioPersonajes.paraCadaElemento(personaje -> System.out.println(personaje));


            // Ordenar libros por título utilizando un Comparator
            System.out.println("\nPersonajes ordenados por nivel:");
            inventarioPersonajes.mostrarContenido((p1, p2) -> Integer.compare(p1.getNivel(), p2.getNivel()));
            inventarioPersonajes.paraCadaElemento(personaje -> System.out.println(personaje));

            // Filtrar libros por Clase MAGO
            System.out.println("\nPersonajes MAGOS:");
            inventarioPersonajes.filtrar(p -> p.getClase().equals(ClasePersonaje.MAGO)).forEach(personaje -> System.out.println(personaje));

            
            // Aumentar nivel en +5
            System.out.println("\nAumentar nivel en +5:");
            inventarioPersonajes.transformar(p -> new Personaje(p.getId(), p.getNombre(), p.getClase(), p.getNivel() + 5));
            inventarioPersonajes.mostrarContenido();

            // ------------------------------------- //
            
            // Guardar el inventario en un archivo binario
            inventarioPersonajes.guardarEnArchivo(PATH_SERIAL); 
            
            // Cargar el inventario desde el archivo binario
            Inventario<Personaje> inventarioCargado = new Inventario<>();
            inventarioCargado.cargarDesdeArchivo(PATH_SERIAL);
            System.out.println("\nPersonajes cargados desde archivo binario:");
            inventarioCargado.paraCadaElemento(p -> System.out.println(p));
            
            // Guardar el inventario en un archivo CSV
            inventarioPersonajes.guardarEnCSV(PATH_CSV);
            
            // Cargar el inventario desde el archivo CSV
            inventarioCargado.cargarDesdeCSV(PATH_CSV);
            System.out.println("\nPersonajes cargados desde archivo CSV:");
            inventarioCargado.paraCadaElemento(p -> System.out.println(p));

        } catch ( NullPointerException| IndexOutOfBoundsException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
    
}
