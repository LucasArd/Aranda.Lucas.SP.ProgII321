
package modelos;

import java.io.Serializable;

@FunctionalInterface
public interface CSVSerializable extends Serializable{
    public String toCSV();

}