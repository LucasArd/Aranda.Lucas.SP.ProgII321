
package modelos;

import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;


public interface Inventariable<T> extends Iterable<T> {
    
    void agregar(T item);
    
    T obtener(int indice);
    
    void eliminar(int indice);
    
    int tamanio();
    
    Iterator<T> iterator();
    
    List<T> filtrar(Predicate<? super T> criterio);
    
    void paraCadaElemento(Consumer<? super T> accion);
    
    void transformar(Function<? super T, ? extends T> transformacion);
}
