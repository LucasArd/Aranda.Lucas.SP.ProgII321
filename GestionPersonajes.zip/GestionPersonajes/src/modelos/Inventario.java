
package modelos;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import servicios.ManejadorArchivos;
import servicios.Serializadora;


public class Inventario<T extends CSVSerializable> implements Inventariable<T> {

    private List<T> personajes = new LinkedList<>();
    
    @Override
    public void agregar(T item) {
        if (item == null) {
            throw new IllegalArgumentException("No puede guardar un NULO");
        }
        personajes.add(item);
    }

    @Override
    public T obtener(int indice) {
        validarIndice(indice);
        return personajes.get(indice);

    }

    @Override
    public void eliminar(int indice) {
        validarIndice(indice);
        personajes.remove(indice);

    }

    @Override
    public int tamanio() {
        return personajes.size();
    }

    @Override
    public Iterator<T> iterator() {
        if (!personajes.isEmpty() && personajes.get(0) instanceof Comparable) {
            return iterator((Comparator<? super T>) Comparator.naturalOrder());
        }
        return (new ArrayList<>(personajes)).iterator();
    }

    public Iterator<T> iterator(Comparator<? super T> comparador) {
        personajes.sort(comparador);
        return personajes.iterator();

    }
    
    private void validarIndice(int indice) {
        if (!(indice > 0 && indice < personajes.size())) {
            throw new IndexOutOfBoundsException("Indice invalido");
        }
    }


    @Override
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> resultado = new ArrayList<>();
        for (T p : personajes) {
            if (criterio.test(p)) {
                resultado.add(p);
            }
        }
        return resultado;
    }
    

    @Override
    public void paraCadaElemento(Consumer<? super T> accion) {
        for (T p : personajes) {
            accion.accept(p);
        }
    }

    @Override
    public void transformar(Function<? super T, ? extends T> transformacion) {
        for (T item : personajes) {
            transformacion.apply(item);
        }
    }
    
    public void mostrarContenido() {
        mostrarContenido((Comparator<? super T>) Comparator.naturalOrder());
    }
    
    public void mostrarContenido(Comparator<? super T> comparador) {
        System.out.println("Personajes : ");
        iterator(comparador); 

    }
    
    // MANEJANDO ARCHIVOS -----
    
    public void guardarEnArchivo(String path) {

        //Serializadora.serializarLibros((List<? extends Libro>)items, path);
        List<CSVSerializable> itemsSerializables = new LinkedList<>();

        for (T p : personajes) {
            if (p instanceof CSVSerializable serializableItem) {
                itemsSerializables.add(serializableItem);
            }
        }
        if (!itemsSerializables.isEmpty()) {
            Serializadora.serializarPersonajes((List<? extends Personaje>) personajes, path);
        } else {
            System.out.println("NO HAY ELEMENTOS GUARDABLES");
        }
    }

    public List<Personaje> cargarDesdeArchivo(String path) {
        List<Personaje> personajes = Serializadora.deserializarPersonajes(path);
        if (personajes == null || personajes.isEmpty()) {
            System.out.println("\nNO HAY PERSONAJES EN EL ARCHIVO.");
            personajes = new ArrayList<>();
        } else {
            System.out.println("\n PERSONAJES CARGADOS.");
            for (Personaje p : personajes) {
                this.agregar((T) p);
            }
        }
        return personajes;
    }

    public void guardarEnCSV(String path) {

        List<CSVSerializable> itemsSerializables = new LinkedList<>();

        for (T p : personajes) {
            if (p instanceof CSVSerializable serializableItem) {
                itemsSerializables.add(serializableItem);
            }
        }
        if (!itemsSerializables.isEmpty()) {
            ManejadorArchivos.guardarPersonajesCSV((List<? extends Personaje>) personajes, path);
            System.out.println("PERSONAJES GUARDADOS EN CSV.");
        } else {
            System.out.println("No hay elementos aptos para el csv.");
        }
    }

    public List<Personaje> cargarDesdeCSV(String path) {
        List<Personaje> personajes = ManejadorArchivos.cargarPersonajesCSV(path);

        if (personajes == null || personajes.isEmpty()) {
            System.out.println("\nNO SE ENCONTRARON PERSONAJES EN EL CSV");
            personajes = new ArrayList<>();
        } 
        
        return personajes;
            
            
    }
    
}
