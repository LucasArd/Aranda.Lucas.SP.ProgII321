
package modelos;


public enum ClasePersonaje {
    GUERRERO,
    MAGO,
    ARQUERO
}
