
package modelos;

public class Personaje implements Comparable<Personaje>, CSVSerializable{
    
    private int id;
    private String nombre;
    private ClasePersonaje clase;
    private int nivel;

    public Personaje(int id, String nombre, ClasePersonaje clase, int nivel) {
        this.id = id;
        this.nombre = nombre;
        this.clase = clase;
        this.nivel = nivel;
    }
    
    public static Personaje fromCSV(String csv) {
    String[] partes = csv.split(",");
    return new Personaje(
        Integer.parseInt(partes[0]),
        partes[1],
        ClasePersonaje.valueOf(partes[2].toUpperCase()),
        Integer.parseInt(partes[3])
    );
    }

    public String getNombre() {
        return nombre;
    }

    public int getNivel() {
        return nivel;
    }

    public ClasePersonaje getClase() {
        return clase;
    }

    public int getId() {
        return id;
    }
    
    
    
    
    
    // CSVSerializable
    @Override
    public String toCSV() {
        return id + "," + nombre + "," + clase + "," + nivel;
    }
    
    @Override
    public int compareTo(Personaje p) { // ordenar por nombre de forma ntural
        return nombre.compareTo(p.nombre); 
    }
    
    
    @Override
    public String toString() {
        return "Personaje{" + "id=" + id + ", nombre=" + nombre + ", clase=" + clase + ", nivel=" + nivel + '}';
    }

}
